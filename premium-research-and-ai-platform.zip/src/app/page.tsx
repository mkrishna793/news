import Link from "next/link";
import { ArrowRight, Flame, Bookmark, Eye, MessageCircle } from "lucide-react";
import { db } from "@/db";
import { projects } from "@/db/schema";
import { ready } from "@/db/ensure";
import { listItems, dailyCounts, readStats, totals } from "@/lib/data";
import { toCard, type Card } from "@/lib/cards";
import { explain } from "@/lib/plain";
import { getSetting } from "@/lib/settings";
import { KIND_META, domainMeta, accentHex } from "@/lib/meta";
import type { Quote } from "@/lib/ingest/videos";
import Scene3D from "@/components/Scene3D";
import Tilt from "@/components/Tilt";
import VideoGrid from "@/components/VideoGrid";
import { ActivityChart, MarketBoard, SectionTitle, Empty } from "@/components/ui";
import { timeAgo } from "@/lib/text";

export const dynamic = "force-dynamic";

function Lane({ kind, cards, domainFilter }: { kind: string; cards: Card[]; domainFilter?: string }) {
  const km = KIND_META[kind];
  if (!cards.length) return null;
  const [first, ...rest] = cards;
  const dm = domainMeta(kind, first.domain);
  return (
    <Tilt color={km.color} className="flex flex-col rounded-3xl p-5" max={3}>
      <div className="mb-3 flex items-center justify-between">
        <Link href={km.href + (domainFilter ? `?d=${domainFilter}` : "")} className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.16em]" style={{ color: km.color }}>
          {km.label} <ArrowRight size={12} />
        </Link>
        <span className="chip" style={{ ["--c" as string]: dm.color }}>{dm.emoji} {dm.label}</span>
      </div>
      <Link href={`/item/${first.id}`} className="clamp-3 text-[17px] font-bold leading-snug text-white after:absolute after:inset-0 hover:text-white">{first.title}</Link>
      <p className="clamp-3 mt-2 text-[13px] leading-relaxed text-soft">{first.essentialWhy ?? first.tldr}</p>
      <div className="relative z-10 mt-4 space-y-2 border-t border-line pt-3">
        {rest.map((c) => (
          <Link key={c.id} href={`/item/${c.id}`} className="group flex items-start gap-2 text-[12.5px] leading-snug text-soft hover:text-white">
            <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: km.color }} />
            <span className="clamp-2">{c.title}</span>
            <span className="ml-auto shrink-0 pt-0.5 text-[10px] text-mute">{timeAgo(c.publishedAt)}</span>
          </Link>
        ))}
      </div>
    </Tilt>
  );
}

export default async function Home() {
  await ready();
  const hour = new Date().getHours();
  const greet = hour < 5 ? "Still up?" : hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  const [neuro, quantum, aiP, inter, radar, applied, industry, geo, vids, ess, daily, stats, tot, market, projs] = await Promise.all([
    listItems({ kind: "paper", domain: "neuro", limit: 3 }),
    listItems({ kind: "paper", domain: "quantum", limit: 3 }),
    listItems({ kind: "paper", domain: "ai", limit: 3 }),
    listItems({ kind: "paper", domain: "inter", limit: 3 }),
    listItems({ kind: "ai_news", limit: 4 }),
    listItems({ kind: "applied", limit: 3 }),
    listItems({ kind: "industry", limit: 4 }),
    listItems({ kind: "geo", limit: 4 }),
    listItems({ kind: "video", limit: 3 }),
    listItems({ kind: "paper", essentials: "only", limit: 40, sort: "latest" }),
    dailyCounts(undefined, 14),
    readStats(),
    totals(),
    getSetting<{ at?: string; quotes?: Quote[] }>("market", {}),
    db.select().from(projects).orderBy(projects.position, projects.id).limit(3),
  ]);
  const total = Object.values(tot).reduce((a, b) => a + b, 0);
  const todays = daily.find((d) => d.day === new Date().toISOString().slice(0, 10))?.n ?? 0;
  const classic = ess.length ? ess[Math.floor(Date.now() / 864e5) % ess.length] : null;
  const classicCard = classic ? toCard(classic) : null;
  const lead = [...aiP, ...neuro, ...quantum][0];
  const questions = lead ? explain({ kind: lead.kind, domain: lead.domain, title: lead.title, summary: lead.summary }).questions.slice(0, 3) : [];

  return (
    <>
      {/* hero */}
      <section className="glass fade-up relative mb-6 overflow-hidden rounded-[2.2rem] px-6 py-10 md:px-12 md:py-14">
        <div className="pointer-events-none absolute -right-16 -top-16 h-[125%] w-[62%] max-md:w-full max-md:opacity-35">
          <Scene3D variant="neural" className="h-full w-full" />
        </div>
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-ink/90 via-ink/40 to-transparent" />
        <div className="relative max-w-2xl">
          <div className="mb-4 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.22em] text-violet"><span className="live-dot" /> {greet}, curious mind</div>
          <h1 className="text-gradient text-4xl font-extrabold leading-[1.02] tracking-tight md:text-6xl">Today’s frontier of science, AI & the world.</h1>
          <p className="mt-4 max-w-xl text-[15px] leading-relaxed text-soft">Atlas reads the open web for you — journals, preprints, labs, communities, markets and world affairs — and explains each story in plain English. No ads. No jargon. Verified across sources.</p>
          <div className="mt-7 flex flex-wrap gap-3">
            <Link href="/research" className="btn btn-primary">Start with research <ArrowRight size={15} /></Link>
            <Link href="/chat" className="btn"><MessageCircle size={15} /> Ask anything</Link>
          </div>
          <div className="mt-8 flex flex-wrap gap-3">
            {[
              { l: "collected", v: total, i: <Eye size={14} /> },
              { l: "new today", v: todays, i: <Flame size={14} /> },
              { l: "day streak", v: stats.streak, i: <Flame size={14} className="text-orange-400" /> },
              { l: "saved", v: stats.saved, i: <Bookmark size={14} /> },
            ].map((s) => (
              <div key={s.l} className="rounded-2xl border border-line bg-black/30 px-4 py-2.5 backdrop-blur">
                <div className="flex items-center gap-1.5 text-xl font-extrabold text-white">{s.i}{s.v}</div>
                <div className="text-[10px] font-semibold uppercase tracking-wider text-mute">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {market.quotes?.length ? <div className="mb-2"><MarketBoard quotes={market.quotes} compact /></div> : null}

      {total === 0 && <div className="mt-6"><Empty title="Atlas is collecting its first batch…" hint="Pulling from arXiv, PubMed, Hugging Face, Reddit, Hacker News, GitHub, YouTube and world news. You’ll see a toast when it’s ready — this page updates itself." /></div>}

      {total > 0 && (
        <>
          <SectionTitle sub="The most important new paper in each field" color="#8b5cf6" action={<Link href="/research" className="btn !text-xs">All research <ArrowRight size={13} /></Link>}>Research today</SectionTitle>
          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
            <Lane kind="paper" cards={neuro.map(toCard)} domainFilter="neuro" />
            <Lane kind="paper" cards={quantum.map(toCard)} domainFilter="quantum" />
            <Lane kind="paper" cards={aiP.map(toCard)} domainFilter="ai" />
            <Lane kind="paper" cards={inter.map(toCard)} domainFilter="inter" />
          </div>

          <SectionTitle sub="Models, open source, builders, markets and the wider world" color="#22d3ee">Across the radar</SectionTitle>
          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
            <Lane kind="ai_news" cards={radar.map(toCard)} />
            <Lane kind="applied" cards={applied.map(toCard)} />
            <Lane kind="industry" cards={industry.map(toCard)} />
            <Lane kind="geo" cards={geo.map(toCard)} />
          </div>

          <div className="mt-9 grid gap-5 lg:grid-cols-[1.3fr_1fr]">
            {classicCard && (
              <Tilt color="#fbbf24" className="relative overflow-hidden rounded-3xl p-7">
                <div className="mb-2 text-[11px] font-bold uppercase tracking-[0.18em] text-amber">🏛️ Classic of the day</div>
                <Link href={`/item/${classicCard.id}`} className="text-2xl font-extrabold leading-tight text-white after:absolute after:inset-0">{classicCard.title}</Link>
                <p className="mt-3 max-w-xl text-[14.5px] leading-relaxed text-soft">{classicCard.essentialWhy}</p>
                <div className="relative z-10 mt-5"><Link href={`/item/${classicCard.id}`} className="btn">Read the plain-English version <ArrowRight size={14} /></Link></div>
              </Tilt>
            )}
            <div className="glass rounded-3xl p-7">
              <div className="mb-3 text-[11px] font-bold uppercase tracking-[0.18em] text-violet">🕳️ Today’s rabbit holes</div>
              <div className="flex flex-col gap-2">
                {questions.map((q) => (
                  <Link key={q} href={`/chat?item=${lead!.id}&q=${encodeURIComponent(q)}`} className="group flex items-center justify-between gap-3 rounded-2xl border border-line bg-white/[0.03] px-4 py-3 text-[13.5px] text-soft transition-all hover:border-violet/50 hover:bg-violet/10 hover:text-white">
                    {q}<ArrowRight size={14} className="text-violet transition-transform group-hover:translate-x-1" />
                  </Link>
                ))}
              </div>
            </div>
          </div>

          {vids.length > 0 && (
            <>
              <SectionTitle sub="Lectures, explainers and builders" color="#f87171" action={<Link href="/videos" className="btn !text-xs">All videos <ArrowRight size={13} /></Link>}>Worth watching</SectionTitle>
              <VideoGrid videos={vids.map(toCard)} />
            </>
          )}
        </>
      )}

      <div className="mt-9 grid gap-5 lg:grid-cols-[1.2fr_1fr]">
        <ActivityChart data={daily} color="#22d3ee" title="Everything gathered per day" />
        <div className="glass rounded-3xl p-5">
          <div className="mb-3 flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-mute"><span>Your projects</span><Link href="/projects" className="text-violet">open →</Link></div>
          {projs.length === 0 ? (
            <p className="text-sm text-mute">Add the projects you’re building — with a repo, goals and a next action — and track real GitHub progress here. <Link href="/projects" className="text-violet underline">Set up →</Link></p>
          ) : (
            <div className="space-y-2.5">
              {projs.map((p) => (
                <Link key={p.id} href="/projects" className="flex items-center gap-3 rounded-2xl border border-line bg-white/[0.03] p-3 transition-colors hover:bg-white/[0.07]">
                  <span className="grid h-10 w-10 place-items-center rounded-xl text-xl" style={{ background: `${accentHex(p.accent)}26` }}>{p.emoji}</span>
                  <div className="min-w-0"><div className="truncate text-sm font-bold text-white">{p.title}</div><div className="truncate text-xs text-mute">{p.nextAction ? `Next: ${p.nextAction}` : p.tagline}</div></div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
