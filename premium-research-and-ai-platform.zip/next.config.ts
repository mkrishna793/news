import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  serverExternalPackages: ["imapflow", "pg"],
  images: { unoptimized: true },
};

export default nextConfig;
