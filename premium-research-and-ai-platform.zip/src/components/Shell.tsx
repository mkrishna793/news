"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import {
  Atom, Bot, Briefcase, Compass, FlaskConical, Globe2, GitBranch, Home, Inbox, Library, Menu, MessagesSquare,
  Newspaper, PlugZap, RefreshCw, Search, Sparkles, Volume2, VolumeX, X, PlayCircle, Flame,
} from "lucide-react";
import { initSound, setSound, soundOn, sfx, type Sfx } from "@/lib/sound";
import type { ToastDetail } from "@/lib/client";

const NAV: { group: string; items: { href: string; label: string; icon: ReactNode; color: string }[] }[] = [
  {
    group: "Discover",
    items: [
      { href: "/", label: "Today", icon: <Home size={17} />, color: "#a78bfa" },
      { href: "/research", label: "Research", icon: <Atom size={17} />, color: "#8b5cf6" },
      { href: "/ai", label: "AI Radar", icon: <Bot size={17} />, color: "#22d3ee" },
      { href: "/applied", label: "AI Applied", icon: <FlaskConical size={17} />, color: "#34d399" },
      { href: "/industry", label: "Industry", icon: <Briefcase size={17} />, color: "#60a5fa" },
      { href: "/world", label: "World", icon: <Globe2 size={17} />, color: "#fb923c" },
    ],
  },
  {
    group: "Watch & read",
    items: [
      { href: "/videos", label: "Videos", icon: <PlayCircle size={17} />, color: "#f87171" },
      { href: "/hn", label: "Hacker News", icon: <Flame size={17} />, color: "#fb923c" },
      { href: "/library", label: "Library", icon: <Library size={17} />, color: "#fbbf24" },
    ],
  },
  {
    group: "Your workspace",
    items: [
      { href: "/projects", label: "Projects", icon: <GitBranch size={17} />, color: "#a78bfa" },
      { href: "/inbox", label: "Inbox", icon: <Inbox size={17} />, color: "#f472b6" },
      { href: "/chat", label: "Ask Atlas", icon: <MessagesSquare size={17} />, color: "#22d3ee" },
      { href: "/connect", label: "Connect", icon: <PlugZap size={17} />, color: "#34d399" },
    ],
  },
];

type Status = { running: boolean; done: number; total: number; lastRun?: string };

export default function Shell({ children }: { children: ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [sound, setS] = useState(true);
  const [status, setStatus] = useState<Status | null>(null);
  const [toasts, setToasts] = useState<(ToastDetail & { id: number })[]>([]);
  const [q, setQ] = useState("");
  const wasRunning = useRef(false);
  const poll = useRef<ReturnType<typeof setTimeout> | null>(null);

  const play = useCallback((n: Sfx) => sfx[n](), []);

  // ----- sounds: one global listener so *everything* clickable feels alive
  useEffect(() => {
    initSound();
    setS(soundOn());
    const down = (e: PointerEvent) => {
      const t = e.target as HTMLElement | null;
      const el = t?.closest<HTMLElement>("[data-sfx],a,button,summary,[role=button],select,label.pill");
      if (!el || (el as HTMLButtonElement).disabled) return;
      const s = el.dataset.sfx as Sfx | undefined;
      if (s === ("none" as Sfx)) return;
      if (s && s in sfx) sfx[s]();
      else if (el.tagName === "A") sfx.open();
      else sfx.click();
    };
    const over = (e: PointerEvent) => {
      const t = e.target as HTMLElement | null;
      if (t?.closest(".tilt,.pill,.btn,nav a")) sfx.hover();
    };
    document.addEventListener("pointerdown", down, true);
    document.addEventListener("pointerover", over, true);
    return () => {
      document.removeEventListener("pointerdown", down, true);
      document.removeEventListener("pointerover", over, true);
    };
  }, []);

  // ----- toasts
  useEffect(() => {
    const h = (e: Event) => {
      const d = (e as CustomEvent<ToastDetail>).detail;
      const id = Date.now() + Math.random();
      setToasts((t) => [...t.slice(-3), { ...d, id }]);
      setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4200);
    };
    window.addEventListener("atlas-toast", h);
    return () => window.removeEventListener("atlas-toast", h);
  }, []);

  // ----- background refresh: updates itself whenever you open the site
  const check = useCallback(
    async (method: "GET" | "POST" = "GET") => {
      try {
        const res = await fetch(method === "POST" ? "/api/refresh" : "/api/refresh?ifStale=1", { method, cache: "no-store" });
        const s = (await res.json()) as Status;
        setStatus(s);
        if (s.running) {
          wasRunning.current = true;
          if (poll.current) clearTimeout(poll.current);
          poll.current = setTimeout(() => void check("GET"), 2500);
        } else if (wasRunning.current) {
          wasRunning.current = false;
          window.dispatchEvent(new CustomEvent<ToastDetail>("atlas-toast", { detail: { text: "Fresh knowledge gathered from across the web ✨", tone: "ok" } }));
          sfx.success();
          router.refresh();
        }
      } catch {
        /* offline is fine */
      }
    },
    [router],
  );
  useEffect(() => {
    void check("GET");
    const iv = setInterval(() => void check("GET"), 15 * 60 * 1000);
    return () => {
      clearInterval(iv);
      if (poll.current) clearTimeout(poll.current);
    };
  }, [check]);

  useEffect(() => setOpen(false), [path]);

  const active = (href: string) => (href === "/" ? path === "/" : path.startsWith(href));
  const nav = (
    <nav className="flex flex-col gap-6 px-3 pb-6">
      {NAV.map((g) => (
        <div key={g.group}>
          <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-[0.18em] text-mute">{g.group}</div>
          <div className="flex flex-col gap-0.5">
            {g.items.map((it) => (
              <Link
                key={it.href}
                href={it.href}
                className={`group relative flex items-center gap-3 rounded-xl px-3 py-2 text-[13.5px] font-medium transition-all ${active(it.href) ? "bg-white/10 text-white" : "text-soft hover:bg-white/5 hover:text-white"}`}
              >
                {active(it.href) && <span className="absolute left-0 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-r-full" style={{ background: it.color, boxShadow: `0 0 14px ${it.color}` }} />}
                <span className="grid h-7 w-7 place-items-center rounded-lg transition-transform group-hover:scale-110" style={{ color: it.color, background: `${it.color}1f` }}>
                  {it.icon}
                </span>
                {it.label}
              </Link>
            ))}
          </div>
        </div>
      ))}
    </nav>
  );

  return (
    <div className="flex min-h-screen">
      {/* desktop sidebar */}
      <aside className="sticky top-0 hidden h-screen w-[250px] shrink-0 flex-col overflow-y-auto border-r border-line bg-black/20 backdrop-blur-xl lg:flex">
        <Link href="/" className="flex items-center gap-3 px-6 py-6">
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-violet via-indigo-500 to-cyan shadow-[0_8px_30px_-6px_rgba(139,92,246,0.9)]">
            <Compass size={20} className="text-white" />
          </span>
          <span>
            <span className="block text-[15px] font-extrabold leading-tight tracking-tight text-white">Curiosity Atlas</span>
            <span className="block text-[11px] text-mute">science · AI · world</span>
          </span>
        </Link>
        {nav}
        <div className="mt-auto px-5 pb-5 text-[11px] leading-relaxed text-mute">
          <div className="glass rounded-2xl p-3">
            <div className="mb-1 flex items-center gap-2 font-semibold text-soft">
              <Sparkles size={13} className="text-amber" /> No ads. No tracking.
            </div>
            Runs on your laptop and reads the open web for you.
          </div>
        </div>
      </aside>

      {/* mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <div className="glass-strong absolute left-0 top-0 h-full w-[270px] overflow-y-auto pt-5">
            <div className="flex items-center justify-between px-5 pb-4">
              <span className="font-extrabold text-white">Curiosity Atlas</span>
              <button className="btn !p-2" onClick={() => setOpen(false)} aria-label="Close menu">
                <X size={16} />
              </button>
            </div>
            {nav}
          </div>
        </div>
      )}

      <div className="min-w-0 flex-1">
        <header className="sticky top-0 z-40 flex items-center gap-3 border-b border-line bg-ink/70 px-4 py-3 backdrop-blur-xl md:px-8">
          <button className="btn !p-2 lg:hidden" onClick={() => setOpen(true)} aria-label="Open menu">
            <Menu size={18} />
          </button>
          <form
            className="relative max-w-xl flex-1"
            onSubmit={(e) => {
              e.preventDefault();
              if (q.trim()) router.push(`/search?q=${encodeURIComponent(q.trim())}`);
            }}
          >
            <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-mute" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search everything you’ve gathered…" className="field !rounded-full !bg-white/5 !py-2 !pl-10 text-[13px]" />
          </form>
          <div className="ml-auto flex items-center gap-2">
            {status?.running ? (
              <span className="chip" style={{ ["--c" as string]: "#34d399" }}>
                <span className="live-dot" /> Gathering {status.done}/{status.total || "…"}
              </span>
            ) : (
              <span className="hidden text-[11px] text-mute md:block">{status?.lastRun ? `Updated ${new Date(status.lastRun).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}` : ""}</span>
            )}
            <button className="btn !p-2.5" title="Refresh all sources now" disabled={!!status?.running} onClick={() => void check("POST")}>
              <RefreshCw size={16} className={status?.running ? "animate-spin" : ""} />
            </button>
            <button
              className="btn !p-2.5"
              title={sound ? "Mute sounds" : "Enable sounds"}
              data-sfx="none"
              onClick={() => {
                setSound(!sound);
                setS(!sound);
              }}
            >
              {sound ? <Volume2 size={16} /> : <VolumeX size={16} />}
            </button>
            <Link href="/chat" className="btn btn-primary hidden md:inline-flex">
              <MessagesSquare size={15} /> Ask Atlas
            </Link>
          </div>
        </header>
        <main className="mx-auto w-full max-w-[1400px] px-4 pb-24 pt-6 md:px-8">{children}</main>
      </div>

      <div className="pointer-events-none fixed bottom-5 right-5 z-[60] flex flex-col gap-2">
        {toasts.map((t) => (
          <div key={t.id} className="toast-in glass-strong pointer-events-auto flex max-w-sm items-center gap-3 rounded-2xl px-4 py-3 text-sm" style={{ borderColor: t.tone === "err" ? "#f8717180" : t.tone === "ok" ? "#34d39980" : undefined }}>
            <Newspaper size={16} className={t.tone === "err" ? "text-red-400" : t.tone === "ok" ? "text-mint" : "text-violet"} />
            {t.text}
          </div>
        ))}
      </div>
      <span className="hidden">{play.name}</span>
    </div>
  );
}
