# 🧭 Curiosity Atlas

A local-first, ad-free dashboard that reads the open web for you and explains it in plain English:

| Section | What you get |
|---|---|
| **Research** | Neuroscience (PubMed journals + q-bio), Quantum (arXiv quant-ph), AI/neural nets (HF Daily Papers + arXiv), Interdisciplinary, plus an "Essential classics" shelf. Each paper: step-by-step plain explanation, glossary, analogy, key numbers, **authors with affiliations/h-index (OpenAlex)**, **figures pulled from the paper**, code/project/PDF links. |
| **AI Radar** | New/trending models (Hugging Face), Reddit, Hacker News, small-lab blogs, open-source releases (Ollama, llama.cpp, Transformers, vLLM), GitHub issues & problems. |
| **AI Applied** | What people build with AI: Show HN, new GitHub projects, HF Spaces, DEV tutorials, AI-for-science preprints. |
| **Industry** | Big-tech news, funding, layoffs, stock/index quotes with good/bad-news signals. |
| **World** | India + world geopolitics, student/education policy, wars, tech geopolitics — simple breakdowns. Local party politics/religion filtered out. |
| **Videos / Hacker News** | 25+ science/tech YouTube channels (privacy player), HN front page & Show HN. |
| **Projects** | Your GitHub projects as living cards: commit momentum, streaks, goals, next action, confetti. |
| **Inbox** | Read-only IMAP radar for 2–3 email accounts. |
| **Ask Atlas** | Chat that searches 7 sources **in parallel**, cross-verifies, and answers with citations. |

## Run it on your laptop

```bash
# 1. Postgres running locally, then:
cp .env.example .env          # edit DATABASE_URL if needed
npm install
npm run build && npm start    # http://localhost:3000
```

Tables are created automatically on first run. The site **refreshes itself** on start and every ~3 hours while it runs (and when you open it and data is stale). No AI is required for anything.

## Connect an AI (optional) — open *Connect*

* **Local model**: Ollama / LM Studio / llama.cpp / Jan → click *Auto-detect*.
* **Coding agent CLI**: any command that reads a prompt on stdin (`claude -p`, `gemini -p ""`, `codex exec -`, `ollama run llama3.2`).
* **MCP** (Antigravity, Claude Code, Cursor, Windsurf, …): add `mcp/bridge.mjs` or `http://localhost:3000/api/mcp`. Tools: `get_digest`, `search_items`, `get_item`, `verify_claim`, `list_projects`, `inbox_summary`, `publish_item`, `save_explanation`, `add_source`, `refresh_sources`. Your agent can **push its own findings onto the site** with `publish_item`.
* **REST**: `POST /api/agent {"tool": "...", "args": {...}}`.

## Notes
* Email passwords are AES-256-GCM encrypted in your local DB. Use app passwords, not real passwords.
* GitHub token (optional, read-only) unlocks private repos, review requests and higher rate limits.
* All data sources are public and key-free (arXiv, PubMed, OpenAlex, Hugging Face, Hacker News, Reddit RSS, GitHub, YouTube RSS, Google News RSS, Yahoo Finance).
