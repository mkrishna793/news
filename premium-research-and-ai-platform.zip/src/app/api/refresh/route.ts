import { ingestStatus, isStale, kickoff } from "@/lib/ingest";

export const dynamic = "force-dynamic";

export async function POST() {
  kickoff();
  return Response.json(await ingestStatus());
}

// GET /api/refresh?ifStale=1  -> refreshes only if the last run is older than 3 hours
export async function GET(req: Request) {
  const u = new URL(req.url);
  if (u.searchParams.get("ifStale") && (await isStale(Number(u.searchParams.get("hours") ?? 3)))) kickoff();
  return Response.json(await ingestStatus());
}
