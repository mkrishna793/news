import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, Clock, ShieldCheck, Users, Lightbulb, BookMarked, Telescope } from "lucide-react";
import { getItem, related } from "@/lib/data";
import { explain } from "@/lib/plain";
import { toCard } from "@/lib/cards";
import { domainMeta, KIND_META } from "@/lib/meta";
import { timeAgo } from "@/lib/text";
import ItemCard from "@/components/ItemCard";
import { EnrichProvider, Figures, Authors, LinksBox } from "@/components/Enrich";
import { ActionBar, AiExplain, MarkRead } from "@/components/ItemActions";
import { getAi, aiEnabled } from "@/lib/ai";
import { Sparkline } from "@/components/ui";

export const dynamic = "force-dynamic";

function Markdownish({ text }: { text: string }) {
  const blocks = text.split(/\n{2,}/);
  const inline = (s: string) => s.split(/(\*\*[^*]+\*\*)/g).map((p, i) => (p.startsWith("**") ? <strong key={i}>{p.slice(2, -2)}</strong> : p));
  return (
    <div className="prose-atlas">
      {blocks.map((b, i) =>
        /^\s*[-*] /m.test(b) ? (
          <ul key={i}>{b.split("\n").map((l, j) => <li key={j}>{inline(l.replace(/^\s*[-*] /, ""))}</li>)}</ul>
        ) : (
          <p key={i}>{inline(b)}</p>
        ),
      )}
    </div>
  );
}

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const id = Number((await params).id);
  const item = Number.isFinite(id) ? await getItem(id) : null;
  if (!item) notFound();
  const p = explain({ kind: item.kind, domain: item.domain, title: item.title, summary: item.summary, tags: item.tags });
  const [rel, ai] = await Promise.all([related(item, 3), getAi()]);
  const dm = domainMeta(item.kind, item.domain);
  const km = KIND_META[item.kind];
  const isPaper = item.kind === "paper" || (item.kind === "applied" && !!item.meta.arxivId);
  const peer = item.meta.peerReviewed as boolean | undefined;
  const maxKw = Math.max(1, ...p.keywords.map((k) => k.count));
  const hn = item.meta.hnUrl as string | undefined;
  const extra = [
    ...(hn ? [{ label: "Hacker News discussion", href: hn }] : []),
    ...(item.meta.redditUrl ? [{ label: "Reddit thread", href: item.meta.redditUrl as string }] : []),
  ];
  const showNumbers = p.numbers.length > 0;

  return (
    <EnrichProvider id={item.id} enabled={isPaper || item.kind === "applied"}>
      <MarkRead id={item.id} />
      <Link href={km?.href ?? "/"} className="btn mb-5 !py-1.5 !text-xs">
        <ArrowLeft size={14} /> Back to {km?.label ?? "home"}
      </Link>

      <header className="glass fade-up relative overflow-hidden rounded-[2rem] p-6 md:p-9" style={{ ["--c" as string]: dm.color }}>
        <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full blur-3xl" style={{ background: `${dm.color}33` }} />
        <div className="relative">
          <div className="mb-4 flex flex-wrap items-center gap-2">
            <span className="chip" style={{ ["--c" as string]: dm.color }}>{dm.emoji} {dm.label}</span>
            <span className="text-xs text-mute">{item.source} · {timeAgo(item.publishedAt)} · {item.publishedAt.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })}</span>
            {peer !== undefined && (
              <span className="chip" style={{ ["--c" as string]: peer ? "#34d399" : "#fbbf24" }}><ShieldCheck size={11} /> {peer ? "Peer-reviewed journal" : "Preprint · not yet peer-reviewed"}</span>
            )}
          </div>
          <h1 className="max-w-4xl text-2xl font-extrabold leading-tight tracking-tight text-white md:text-4xl">{item.title}</h1>
          {item.authors.length > 0 && (
            <p className="mt-3 flex items-start gap-2 text-sm text-soft">
              <Users size={15} className="mt-0.5 shrink-0 text-mute" />
              <span>{item.authors.slice(0, 6).join(", ")}{item.authors.length > 6 ? ` and ${item.authors.length - 6} more` : ""}</span>
            </p>
          )}
          <div className="mt-6"><ActionBar id={item.id} saved={item.saved} /></div>
        </div>
      </header>

      <div className="mt-7 grid gap-6 lg:grid-cols-[minmax(0,1fr)_340px]">
        <div className="min-w-0 space-y-6">
          {/* TLDR */}
          <section className="glass rounded-3xl p-6" style={{ ["--c" as string]: dm.color }}>
            <div className="mb-2 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.16em]" style={{ color: dm.color }}>
              <Lightbulb size={14} /> In plain English
              <span className="ml-auto flex items-center gap-1 font-medium normal-case tracking-normal text-mute"><Clock size={12} /> {p.readMinutes} min · {p.level}</span>
            </div>
            <p className="text-[18px] font-semibold leading-relaxed text-white">{item.meta.why ?? p.tldr}</p>
            {p.analogy && (
              <div className="mt-4 rounded-2xl border border-amber/30 bg-amber/[0.07] p-4 text-[14px] leading-relaxed text-amber-100/90">
                <b className="text-amber">💭 In everyday terms: </b>{/^like /i.test(p.analogy) ? `It’s ${p.analogy}` : p.analogy}
              </div>
            )}
          </section>

          {/* Story flow */}
          {p.sections.length > 0 && (
            <section>
              <h2 className="mb-3 text-[11px] font-bold uppercase tracking-[0.16em] text-mute">The story, step by step</h2>
              <div className="relative grid gap-4 md:grid-cols-2">
                {p.sections.map((s, i) => (
                  <div key={s.key} className="glass tilt-none group relative rounded-3xl p-5 transition-colors hover:border-white/20" style={{ ["--c" as string]: dm.color }}>
                    <div className="mb-2 flex items-center gap-3">
                      <span className="grid h-9 w-9 place-items-center rounded-xl text-lg" style={{ background: `${dm.color}22` }}>{s.icon}</span>
                      <div>
                        <div className="text-[10px] font-bold uppercase tracking-widest text-mute">Step {i + 1}</div>
                        <div className="font-bold text-white">{s.title}</div>
                      </div>
                    </div>
                    <p className="text-[14px] leading-relaxed text-soft">{s.text}</p>
                    {i < p.sections.length - 1 && <span className="absolute -bottom-3 left-1/2 hidden h-3 w-px bg-gradient-to-b from-white/30 to-transparent md:block" />}
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* numbers */}
          {showNumbers && (
            <section>
              <h2 className="mb-3 text-[11px] font-bold uppercase tracking-[0.16em] text-mute">Numbers that matter</h2>
              <div className="grid gap-3 sm:grid-cols-2">
                {p.numbers.map((n) => (
                  <div key={n.value} className="glass rounded-3xl p-5">
                    <div className="text-3xl font-extrabold" style={{ color: dm.color }}>{n.value}</div>
                    <div className="mt-1 text-[12.5px] leading-snug text-mute">{n.context}</div>
                    <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/10"><div className="bar-grow h-full rounded-full" style={{ width: "100%", background: `linear-gradient(90deg, ${dm.color}, transparent)` }} /></div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* AI deeper */}
          <section className="glass rounded-3xl p-6">
            <div className="mb-3 flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.16em] text-cyan"><Telescope size={14} /> Deeper explanation</div>
              <div className="ml-auto">{aiEnabled(ai) ? <AiExplain id={item.id} hasAi={!!item.ai} /> : <Link href="/connect" className="btn !text-xs">Connect an AI for deeper explanations</Link>}</div>
            </div>
            {item.ai ? (
              <>
                <Markdownish text={item.ai.text} />
                <p className="text-[11px] text-mute">Written by {item.ai.model ?? "your AI"} · {timeAgo(item.ai.at)} — always double-check with the original.</p>
              </>
            ) : (
              <p className="text-sm text-mute">The explanation above is generated by Atlas’s built-in algorithm (no AI). Connect a local model or coding agent in Connect and one click here writes a longer, friendlier explanation.</p>
            )}
          </section>

          {isPaper && <Figures />}
          {(isPaper || item.kind === "applied") && <Authors fallback={item.authors.slice(0, 12)} />}

          {/* glossary */}
          {p.glossary.length > 0 && (
            <section className="glass rounded-3xl p-6">
              <div className="mb-4 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.16em] text-mute"><BookMarked size={14} /> Words you might not know</div>
              <dl className="grid gap-3 sm:grid-cols-2">
                {p.glossary.map((g) => (
                  <div key={g.term} className="rounded-2xl border border-line bg-white/[0.03] p-3.5">
                    <dt className="text-[13px] font-bold capitalize text-white">{g.term}</dt>
                    <dd className="mt-1 text-[12.5px] leading-relaxed text-soft">{g.meaning}</dd>
                  </div>
                ))}
              </dl>
            </section>
          )}

          {/* original text */}
          {item.summary && (
            <details className="glass group rounded-3xl p-5">
              <summary className="cursor-pointer text-[11px] font-bold uppercase tracking-[0.16em] text-mute">Read the original abstract / excerpt</summary>
              <p className="mt-3 text-[13.5px] leading-relaxed text-soft">{item.summary}</p>
            </details>
          )}

          {/* curiosity */}
          <section className="glass rounded-3xl p-6">
            <div className="mb-3 text-[11px] font-bold uppercase tracking-[0.16em] text-violet">🕳️ Fall down the rabbit hole</div>
            <div className="flex flex-col gap-2">
              {p.questions.map((q) => (
                <Link key={q} href={`/chat?item=${item.id}&q=${encodeURIComponent(q)}`} className="group flex items-center justify-between gap-3 rounded-2xl border border-line bg-white/[0.03] px-4 py-3 text-[14px] text-soft transition-all hover:border-violet/50 hover:bg-violet/10 hover:text-white">
                  {q}<span className="text-violet transition-transform group-hover:translate-x-1">→</span>
                </Link>
              ))}
            </div>
          </section>
        </div>

        <aside className="space-y-6 lg:sticky lg:top-24 lg:self-start">
          <LinksBox original={item.url} extra={extra} />
          <div className="glass rounded-3xl p-5">
            <div className="mb-3 text-[11px] font-bold uppercase tracking-wider text-mute">Trust check</div>
            <ul className="space-y-2 text-[13px] text-soft">
              <li>{peer === true ? "✅ Published in a peer-reviewed journal" : peer === false ? "⚠️ Preprint — scientists haven’t formally reviewed it yet" : "ℹ️ News / community item — verify before sharing"}</li>
              <li>{item.meta.github ? "✅ Code is public — others can test it" : "➖ No public code found"}</li>
              <li>{item.score > 60 ? "🔥 Lots of community attention" : "🌱 Early — little discussion so far"}</li>
            </ul>
            <Link href={`/chat?item=${item.id}&q=${encodeURIComponent("Verify this against other sources")}`} className="btn btn-primary mt-4 w-full justify-center">Cross-check with 7 sources</Link>
          </div>
          {p.keywords.length > 0 && (
            <div className="glass rounded-3xl p-5">
              <div className="mb-3 text-[11px] font-bold uppercase tracking-wider text-mute">What it’s about</div>
              <div className="space-y-2">
                {p.keywords.slice(0, 7).map((k) => (
                  <div key={k.word}>
                    <div className="mb-1 flex justify-between text-[12px]"><span className="text-soft">{k.word}</span><span className="text-mute">{k.count}×</span></div>
                    <div className="h-1.5 overflow-hidden rounded-full bg-white/10"><div className="bar-grow h-full rounded-full" style={{ width: `${(k.count / maxKw) * 100}%`, background: dm.color }} /></div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {item.score > 0 && (
            <div className="glass flex items-center justify-between rounded-3xl p-5">
              <div><div className="text-[11px] font-bold uppercase tracking-wider text-mute">Buzz score</div><div className="text-2xl font-extrabold text-white">{Math.round(item.quality)}</div></div>
              <Sparkline data={[2, 4, 3, 6, 5, 8, 7, Math.min(12, 4 + item.quality / 15)]} color={dm.color} w={100} h={36} />
            </div>
          )}
        </aside>
      </div>

      {rel.length > 0 && (
        <section className="mt-12">
          <h2 className="mb-4 text-xl font-extrabold text-white">Go deeper — related</h2>
          <div className="grid gap-5 md:grid-cols-3">{rel.map((r) => <ItemCard key={r.id} c={toCard(r)} compact />)}</div>
        </section>
      )}
    </EnrichProvider>
  );
}
